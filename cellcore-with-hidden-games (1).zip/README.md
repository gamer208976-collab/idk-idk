# CellCore

CellCore is a cell biology learning page with detailed notes and a hidden interactive section revealed by entering `1342` in the blank number field at the bottom.

## Deploy on Netlify
1. Sign in at https://app.netlify.com/.
2. Deploy manually by dragging this folder or its contents into the deploy area.
3. Set your preferred available site name in Netlify site settings.

The page includes Sans Fight (embedded from its original host), Snake, and Block Clicker. Sans Fight may open in a new tab if the original host blocks embedding.
